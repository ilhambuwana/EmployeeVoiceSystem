document.addEventListener("DOMContentLoaded", function () {
	var swiper = new Swiper(".swiper", {
	  // Optional parameters
	  slidesPerView: 1,
	  spaceBetween: 20,
	  loop: true,
  
	  // Navigation arrows
	  navigation: {
		nextEl: ".swiper-button-next",
		prevEl: ".swiper-button-prev",
	  },
  
	  // Pagination
	  pagination: {
		el: ".swiper-pagination",
		clickable: true,
	  },
	});
  });
  